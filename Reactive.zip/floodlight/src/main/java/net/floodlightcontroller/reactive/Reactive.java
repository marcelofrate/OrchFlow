package net.floodlightcontroller.reactive;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.projectfloodlight.openflow.protocol.OFFlowMod;
import org.projectfloodlight.openflow.protocol.OFMessage;
import org.projectfloodlight.openflow.protocol.OFType;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.action.OFActionOutput;
import org.projectfloodlight.openflow.protocol.match.Match;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.types.DatapathId;
import org.projectfloodlight.openflow.types.EthType;
import org.projectfloodlight.openflow.types.IPv4Address;
import org.projectfloodlight.openflow.types.IpProtocol;
import org.projectfloodlight.openflow.types.OFBufferId;
import org.projectfloodlight.openflow.types.OFPort;
import org.projectfloodlight.openflow.types.TransportPort;
import org.projectfloodlight.openflow.types.U64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.floodlightcontroller.core.FloodlightContext;
import net.floodlightcontroller.core.IFloodlightProviderService;
import net.floodlightcontroller.core.IOFMessageListener;
import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.core.internal.IOFSwitchService;
import net.floodlightcontroller.core.module.FloodlightModuleContext;
import net.floodlightcontroller.core.module.FloodlightModuleException;
import net.floodlightcontroller.core.module.IFloodlightModule;
import net.floodlightcontroller.core.module.IFloodlightService;
import net.floodlightcontroller.packet.Ethernet;
import net.floodlightcontroller.packet.IPv4;
import net.floodlightcontroller.packet.TCP;
import net.floodlightcontroller.packet.UDP;
import net.floodlightcontroller.restserver.IRestApiService;

public class Reactive implements IOFMessageListener, IFloodlightModule {
	protected IFloodlightProviderService floodlightProvider;
	protected static Logger logger;
	protected IRestApiService restApiService;
	protected IOFSwitchService switchService;
	private static ArrayList<FlowMap> map = new ArrayList<>();

	@Override
	public String getName() {
		return Reactive.class.getSimpleName();
	}

	@Override
	public boolean isCallbackOrderingPrereq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCallbackOrderingPostreq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleServices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Class<? extends IFloodlightService>, IFloodlightService> getServiceImpls() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleDependencies() {
		Collection<Class<? extends IFloodlightService>> l = new ArrayList<Class<? extends IFloodlightService>>();
		l.add(IFloodlightProviderService.class);
		// Adiciona o REST API ao modulo
		l.add(IRestApiService.class);
		return l;
	}

	@Override
	public void init(FloodlightModuleContext context) throws FloodlightModuleException {
		floodlightProvider = context.getServiceImpl(IFloodlightProviderService.class);
		logger = LoggerFactory.getLogger(Reactive.class);
		// Inicializa o REST API
		restApiService = context.getServiceImpl(IRestApiService.class);
		switchService = context.getServiceImpl(IOFSwitchService.class);
	}

	@Override
	public void startUp(FloodlightModuleContext context) {
		floodlightProvider.addOFMessageListener(OFType.PACKET_IN, this);
		// Registra o REST API
		restApiService.addRestletRoutable(new ReactiveWebRoutable());
	}

	@Override
	public net.floodlightcontroller.core.IListener.Command receive(IOFSwitch sw, OFMessage msg,
			FloodlightContext cntx) {

		// Verifica se a tabela esta vazia
		if (map.isEmpty()) {
			logger.info("A tabela Reactive esta vazia!");
			return Command.CONTINUE;
		}

		switch (msg.getType()) {
		case PACKET_IN:
			Ethernet eth = IFloodlightProviderService.bcStore.get(cntx, IFloodlightProviderService.CONTEXT_PI_PAYLOAD);

			if (eth.getEtherType() == EthType.IPv4) {
				IPv4 ipv4 = (IPv4) eth.getPayload();

				for (int i = 0; i < map.size(); i++) {
					boolean proto = true;
					boolean ip_src = true;
					boolean ip_dst = true;

					if (map.get(i).getIpv4_src() != null) {
						ip_src = String.valueOf(ipv4.getSourceAddress()).equals(map.get(i).getIpv4_src());
					}
					if (map.get(i).getIpv4_dst() != null) {
						ip_dst = String.valueOf(ipv4.getDestinationAddress()).equals(map.get(i).getIpv4_dst());
					}
					if (map.get(i).getIp_proto() != null) {
						proto = Integer.decode(String.valueOf(ipv4.getProtocol()))
								.equals(Integer.decode(map.get(i).getIp_proto()));
					}

					if (proto && ip_src && ip_dst) {
						boolean in_port = true;
						boolean out_port = true;
						System.out.println("---- blz");
						if (ipv4.getProtocol().equals(IpProtocol.TCP)) {
							TCP tcp = (TCP) ipv4.getPayload();

							if (map.get(i).getTp_src() != null) {
								in_port = String.valueOf(tcp.getSourcePort()).equals(map.get(i).getTp_src());
							}
							if (map.get(i).getTp_dst() != null) {
								out_port = String.valueOf(tcp.getDestinationPort()).equals(map.get(i).getTp_dst());
							}
						} else if (ipv4.getProtocol().equals(IpProtocol.UDP)) {
							UDP udp = (UDP) ipv4.getPayload();

							if (map.get(i).getTp_src() != null) {
								in_port = String.valueOf(udp.getSourcePort()).equals(map.get(i).getTp_src());
							}
							if (map.get(i).getTp_dst() != null) {
								out_port = String.valueOf(udp.getDestinationPort()).equals(map.get(i).getTp_dst());
							}
						}

						if (out_port && in_port) {
							try {
								createRoute(map.get(i));
							} catch (UnknownHostException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							System.out.println("### SUCESSO ###");
						}
					}
				}
				logger.info("A rota para {} nao consta na tabela!", ipv4.getDestinationAddress().toString());
			}
			break;
		default:
			break;
		}
		return Command.CONTINUE;
	}

	private void createRoute(FlowMap m) throws UnknownHostException {
		if (m.getDPID() != null) {
			DatapathId dpid = DatapathId.of(m.getDPID());
			IOFSwitch sw = switchService.getSwitch(dpid);

			if (sw == null) {
				if (logger.isWarnEnabled()) {
					logger.warn("Unable to push route, switch at DPID {} " + "not available", dpid);
				}
			} else {

				OFFlowMod.Builder fmb = sw.getOFFactory().buildFlowAdd();
				OFActionOutput.Builder aob = sw.getOFFactory().actions().buildOutput();
				List<OFAction> actions = new ArrayList<OFAction>();
				Match.Builder mb = sw.getOFFactory().buildMatch();

				if (String.valueOf(EthType.IPv4).equals(m.getEth_type())) {
					IPv4Address src = IPv4Address.of(Inet4Address.getByName(m.getIpv4_src()).getAddress());
					IPv4Address dst = IPv4Address.of(Inet4Address.getByName(m.getIpv4_dst()).getAddress());

					mb.setExact(MatchField.ETH_TYPE, EthType.IPv4);
					mb.setExact(MatchField.IPV4_DST, dst);
					mb.setExact(MatchField.IPV4_SRC, src);

					if (String.valueOf(IpProtocol.TCP).equals(m.getIp_proto())) {
						TransportPort TPsrc;
						if (m.getTp_src() != null) {
							TPsrc = TransportPort.of(Integer.decode(m.getTp_src()));
							mb.setExact(MatchField.TCP_SRC, TPsrc);
						}
						TransportPort TPdst;
						if (m.getTp_dst() != null) {
							TPdst = TransportPort.of(Integer.decode(m.getTp_dst()));
							mb.setExact(MatchField.TCP_DST, TPdst);
						}

						mb.setExact(MatchField.IP_PROTO, IpProtocol.TCP);
					} else if (String.valueOf(IpProtocol.UDP).equals(m.getIp_proto())) {
						TransportPort TPsrc;
						if (m.getTp_src() != null) {
							TPsrc = TransportPort.of(Integer.decode(m.getTp_src()));
							mb.setExact(MatchField.UDP_SRC, TPsrc);
						}
						TransportPort TPdst;
						if (m.getTp_dst() != null) {
							TPdst = TransportPort.of(Integer.decode(m.getTp_dst()));
							mb.setExact(MatchField.UDP_DST, TPdst);
						}

						mb.setExact(MatchField.IP_PROTO, IpProtocol.UDP);
					}
				} else if (String.valueOf(EthType.IPv6).equals(m.getEth_type())) {
					mb.setExact(MatchField.ETH_TYPE, EthType.IPv6);
				}

				if (m.getOut_port() != null) {
					OFPort outPort = OFPort.of(Integer.parseInt(m.getOut_port()));
					aob.setPort(outPort);
					aob.setMaxLen(Integer.MAX_VALUE);
					actions.add(aob.build());

					fmb.setActions(actions);
					fmb.setMatch(mb.build());
					fmb.setBufferId(OFBufferId.NO_BUFFER);
					fmb.setCookie(U64.parseHex(m.getCookie()));
					fmb.setOutPort(outPort);
					fmb.setPriority(Integer.parseInt(m.getPriority()));
					if (m.getIdle_timeout() != null) {
						fmb.setIdleTimeout(Integer.parseInt(m.getIdle_timeout()));
					}
					if (m.getHard_timeout() != null) {
						fmb.setIdleTimeout(Integer.parseInt(m.getHard_timeout()));
					}

					sw.write(fmb.build());
				}
			}
		}
	}

	// Recebe a tabela
	public static void setMap(ArrayList<FlowMap> map) {
		Reactive.map = map;
	}

}
