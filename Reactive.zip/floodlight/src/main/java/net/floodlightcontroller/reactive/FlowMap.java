package net.floodlightcontroller.reactive;

public class FlowMap {
	String name, active, idle_timeout, hard_timeout, priority, cookie, eth_type, ip_proto, tp_src, tp_dst, ipv4_src,
			ipv4_dst, DPID, out_port;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getIdle_timeout() {
		return idle_timeout;
	}

	public void setIdle_timeout(String idle_timeout) {
		this.idle_timeout = idle_timeout;
	}

	public String getHard_timeout() {
		return hard_timeout;
	}

	public void setHard_timeout(String hard_timeout) {
		this.hard_timeout = hard_timeout;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getCookie() {
		return cookie;
	}

	public void setCookie(String cookie) {
		this.cookie = cookie;
	}

	public String getEth_type() {
		return eth_type;
	}

	public void setEth_type(String eth_type) {
		this.eth_type = eth_type;
	}

	public String getIp_proto() {
		return ip_proto;
	}

	public void setIp_proto(String ip_proto) {
		this.ip_proto = ip_proto;
	}

	public String getTp_src() {
		return tp_src;
	}

	public void setTp_src(String tp_src) {
		this.tp_src = tp_src;
	}

	public String getTp_dst() {
		return tp_dst;
	}

	public void setTp_dst(String tp_dst) {
		this.tp_dst = tp_dst;
	}

	public String getIpv4_src() {
		return ipv4_src;
	}

	public void setIpv4_src(String ipv4_src) {
		this.ipv4_src = ipv4_src;
	}

	public String getIpv4_dst() {
		return ipv4_dst;
	}

	public void setIpv4_dst(String ipv4_dst) {
		this.ipv4_dst = ipv4_dst;
	}

	public String getDPID() {
		return DPID;
	}

	public void setDPID(String dPID) {
		DPID = dPID;
	}

	public String getOut_port() {
		return out_port;
	}

	public void setOut_port(String out_port) {
		this.out_port = out_port;
	}
}