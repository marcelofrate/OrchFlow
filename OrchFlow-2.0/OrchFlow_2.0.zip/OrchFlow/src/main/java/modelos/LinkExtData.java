package modelos;

public class LinkExtData {
	private String DPID, port, number;

	public String getDPID() {
		return DPID;
	}

	public void setDPID(String DPID) {
		this.DPID = DPID;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
}
