package net.floodlightcontroller.arpreply;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.MappingJsonFactory;

public class ARPReplyPusher extends ServerResource {
	@Post
	public String store(String json) throws IOException {
		MappingJsonFactory f = new MappingJsonFactory();
		JsonParser jp;
		Map<String, String> map = new TreeMap<String, String>();

		try {
			jp = f.createParser(json);
		} catch (JsonParseException e) {
			throw new IOException(e);
		}

		jp.nextToken();
		if (jp.getCurrentToken() != JsonToken.START_OBJECT) {
			throw new IOException("Expected START_OBJECT");
		}

		jp.nextToken();
		if (jp.getCurrentToken() != JsonToken.FIELD_NAME) {
			throw new IOException("Expected FIELD_NAME");
		}

		jp.nextToken();
		if (jp.getCurrentToken() != JsonToken.START_ARRAY) {
			throw new IOException("Expected START_ARRAY");
		}

		while (jp.nextToken() != JsonToken.END_ARRAY) {
			IpMacMap m = new IpMacMap();
			
			if (jp.getCurrentToken() != JsonToken.START_OBJECT) {
				throw new IOException("Expected START_OBJECT");
			}
			
			jp.nextToken();
			if (jp.getCurrentToken() != JsonToken.FIELD_NAME) {
				throw new IOException("Expected FIELD_NAME");
			}

			while (jp.getCurrentToken() != JsonToken.END_OBJECT) {
				if (jp.getCurrentToken() != JsonToken.FIELD_NAME) {
					throw new IOException("Expected FIELD_NAME");
				}
				String n = jp.getCurrentName();

				jp.nextToken();

				switch (n) {
				case "ip":
					m.setIp(jp.getText());
					jp.nextToken();
					break;
				case "mac":
					m.setMac(jp.getText());
					jp.nextToken();
					break;
				}
			}
			map.put(m.getIp().toString(), m.getMac().toString());
		}
		ARPReply.setMap(map);
		return ("{\"status\" : \"" + "Pushed" + "\"}");
	}
}
