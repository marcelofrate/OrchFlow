package net.floodlightcontroller.arpreply;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.projectfloodlight.openflow.protocol.OFMessage;
import org.projectfloodlight.openflow.protocol.OFPacketIn;
import org.projectfloodlight.openflow.protocol.OFPacketOut;
import org.projectfloodlight.openflow.protocol.OFType;
import org.projectfloodlight.openflow.protocol.OFVersion;
import org.projectfloodlight.openflow.protocol.action.OFAction;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.types.EthType;
import org.projectfloodlight.openflow.types.MacAddress;
import org.projectfloodlight.openflow.types.OFPort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.floodlightcontroller.core.FloodlightContext;
import net.floodlightcontroller.core.IFloodlightProviderService;
import net.floodlightcontroller.core.IOFMessageListener;
import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.core.module.FloodlightModuleContext;
import net.floodlightcontroller.core.module.FloodlightModuleException;
import net.floodlightcontroller.core.module.IFloodlightModule;
import net.floodlightcontroller.core.module.IFloodlightService;
import net.floodlightcontroller.packet.ARP;
import net.floodlightcontroller.packet.Ethernet;
import net.floodlightcontroller.packet.IPacket;
import net.floodlightcontroller.restserver.IRestApiService;

public class ARPReply implements IFloodlightModule, IOFMessageListener {
	protected IFloodlightProviderService floodlightProvider;
	protected IRestApiService restApiService;
	protected static Logger logger;
	private static Map<String, String> map = new HashMap<>();

	@Override
	public String getName() {
		return ARPReply.class.getSimpleName();
	}

	@Override
	public boolean isCallbackOrderingPrereq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCallbackOrderingPostreq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public net.floodlightcontroller.core.IListener.Command receive(IOFSwitch sw, OFMessage msg,
			FloodlightContext cntx) {

		// Verifica se a tabela(IP/MAC) esta vazia
		if (map.isEmpty()) {
			logger.info("A tabela ARPReply esta vazia!");
			return Command.CONTINUE;
		}

		switch (msg.getType()) {
		case PACKET_IN:
			Ethernet eth = IFloodlightProviderService.bcStore.get(cntx, IFloodlightProviderService.CONTEXT_PI_PAYLOAD);

			OFPacketIn pi = (OFPacketIn) msg;

			if (eth.getEtherType() == EthType.ARP) {
				ARP arp = (ARP) eth.getPayload();

				// Verifica se o IP esta na topologia
				String s = search(arp.getTargetProtocolAddress().toString());
				if (s != null) {
					// Envia o ARPReply com o MAC desejado
					arpReply(arp, MacAddress.of(s), eth.getPriorityCode(), sw, pi);
				} else {
					logger.info(" O IP {} nao pode ser alcancado!", arp.getTargetProtocolAddress().toString());
				}
			}
			break;
		default:
			break;
		}
		return Command.CONTINUE;
	}

	// Envia o ARPReply para host
	private void arpReply(ARP in, MacAddress MacDst, byte pc, IOFSwitch sw, OFPacketIn pi) {
		ARP arp = new ARP();
		arp.setHardwareType(ARP.HW_TYPE_ETHERNET);
		arp.setProtocolType(ARP.PROTO_TYPE_IP);
		arp.setHardwareAddressLength((byte) 6);
		arp.setProtocolAddressLength((byte) 4);
		arp.setOpCode(ARP.OP_REPLY);
		arp.setSenderHardwareAddress(MacDst);
		arp.setSenderProtocolAddress(in.getTargetProtocolAddress());
		arp.setTargetHardwareAddress(in.getSenderHardwareAddress());
		arp.setTargetProtocolAddress(in.getSenderProtocolAddress());

		Ethernet ether = new Ethernet();
		ether.setEtherType(EthType.ARP);
		ether.setSourceMACAddress(MacDst);
		ether.setDestinationMACAddress(in.getSenderHardwareAddress());
		ether.setPad(true);
		ether.setPayload((IPacket) arp);

		byte[] packet = ether.serialize();
		OFPort inPort = pi.getVersion().compareTo(OFVersion.OF_12) < 0 ? pi.getInPort()
				: (OFPort) pi.getMatch().get(MatchField.IN_PORT);
		OFPacketOut po = sw.getOFFactory().buildPacketOut().setData(packet)
				.setActions(
						Collections.singletonList((OFAction) sw.getOFFactory().actions().output(inPort, 0xffFFffFF)))
				.setInPort(OFPort.CONTROLLER).build();

		sw.write(po);
	}

	// Busca o MAC na tabela(IP/MAC)
	private String search(String ip) {
		String value = null;
		value = map.get(ip);
		return value;
	}

	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleServices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Class<? extends IFloodlightService>, IFloodlightService> getServiceImpls() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleDependencies() {
		Collection<Class<? extends IFloodlightService>> l = new ArrayList<Class<? extends IFloodlightService>>();
		l.add(IFloodlightProviderService.class);
		// Adiciona o REST API ao modulo
		l.add(IRestApiService.class);
		return l;
	}

	@Override
	public void init(FloodlightModuleContext context) throws FloodlightModuleException {
		floodlightProvider = context.getServiceImpl(IFloodlightProviderService.class);
		logger = LoggerFactory.getLogger(ARPReply.class);
		// Inicializa o REST API
		restApiService = context.getServiceImpl(IRestApiService.class);
	}

	@Override
	public void startUp(FloodlightModuleContext context) {
		floodlightProvider.addOFMessageListener(OFType.PACKET_IN, this);
		// Registra o REST API
		restApiService.addRestletRoutable(new ARPReplyWebRoutable());
	}

	// Recebe a tabela(IP/MAC)
	public static void setMap(Map<String, String> map) {
		ARPReply.map = map;
	}

}
